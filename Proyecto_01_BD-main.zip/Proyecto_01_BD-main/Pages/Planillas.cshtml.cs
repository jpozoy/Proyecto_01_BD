using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Proyecto_01_BD.Pages
{
    public class PlanillasModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
