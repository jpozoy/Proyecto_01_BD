using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Proyecto_01_BD.Pages
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
