using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Proyecto_01_BD.Pages
{
    public class VentasModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
